--Execute the following statement by ordinary user
/******************************************************************************/
/*                                                                            */
/*                            OBS related tables                              */
/*                                                                            */
/******************************************************************************/
drop table T_HUAWEI_TASK cascade constraint
/
--The task table(It's used to store the obs task)
create table T_HUAWEI_TASK
(
  SSERVICEID         VARCHAR2(30) not null,
  SDESCRIPTION       VARCHAR2(100),
  DEVICETYPE         NUMBER,
  SDEVICESIGN        VARCHAR2(200),
  SUBCCNO            NUMBER default 1 not null,
  VDNID              NUMBER default 1 not null,
  SCALLERNO          VARCHAR2(24),
  SBEGINDATE         VARCHAR2(19),
  SENDDATE           VARCHAR2(19),
  SBEGINTIME1        VARCHAR2(5),
  SENDTIME1          VARCHAR2(5),
  SBEGINTIME2        VARCHAR2(5),
  SENDTIME2          VARCHAR2(5),
  SBEGINTIME3        VARCHAR2(5),
  SENDTIME3          VARCHAR2(5),
  SHOLIDAYBEGINTIME1 VARCHAR2(5),
  SHOLIDAYENDTIME1   VARCHAR2(5),
  SHOLIDAYBEGINTIME2 VARCHAR2(5),
  SHOLIDAYENDTIME2   VARCHAR2(5),
  SHOLIDAYBEGINTIME3 VARCHAR2(5),
  SHOLIDAYENDTIME3   VARCHAR2(5),
  HOLIDAYID          NUMBER,
  OBSCALLINTERVAL    NUMBER,
  OBSCALLCOUNT       NUMBER,
  OUTBOUNDTYPE       NUMBER,
  MAXALERTINGTIME    NUMBER,
  PREDICTMETHOD      NUMBER,
  FORCECASTTIME      NUMBER default 300,
  PARA1              NUMBER,
  PARA2              NUMBER,
  PARA3              NUMBER,
  PARA4              NUMBER,
  PARA5              NUMBER,
  PARA6              NUMBER
)
tablespace ts_obs
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
	next 2M
    minextents 1
    maxextents unlimited
  );
  
alter table T_HUAWEI_TASK
  add primary key (SSERVICEID)
  using index 
  tablespace ts_obs
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
	next 2M
    minextents 1
    maxextents unlimited
  );

drop table T_HUAWEI_OBS_USERDATA cascade constraint
/
--Use's data table(It's used to store the user's data of the task)
create table T_HUAWEI_OBS_USERDATA
(
  UNIQUEID    VARCHAR2(20) not null,
  SSERVICEID  VARCHAR2(30) not null,
  PHONENUMBER VARCHAR2(120),
  CALLDATA    VARCHAR2(1024),
  CALLCOUNT   NUMBER default 0,
  SSTATUS     VARCHAR2(4),
  DEVICETYPE  NUMBER,
  SSUCCTEL    VARCHAR2(24),
  SFAILCODE   VARCHAR2(5),
  SUBCCNO     NUMBER default 1 not null,
  VDNID       NUMBER default 1 not null
)
tablespace ts_obs
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 2M
	next 2M
    minextents 1
    maxextents unlimited
  );
  
alter table T_HUAWEI_OBS_USERDATA
  add primary key (UNIQUEID)
  using index 
  tablespace ts_obs
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
	next 2M
    minextents 1
    maxextents unlimited
  );
  
alter table T_HUAWEI_OBS_USERDATA
  add foreign key (SSERVICEID)
  references T_HUAWEI_TASK (SSERVICEID);
