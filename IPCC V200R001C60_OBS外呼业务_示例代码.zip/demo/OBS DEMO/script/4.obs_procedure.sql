/******************************************************************************/
/*                                                                            */
/*                            OBS related procedure                           */
/*                                                                            */
/******************************************************************************/
--Judge whether it's holiday
--I_HOLIDAYID     The ID of holiady
--I_SUBCCNO       The ID of CCS
--I_VDNID         The ID of VDN
--O_ISHOLIDAY     whether it's holiday,  0 means it's no holiday, 1 means it's holiday
CREATE OR REPLACE PROCEDURE SP_HUAWEI_GETHOLIDAY
(
    I_HOLIDAYID     IN   INT,
    I_SUBCCNO       IN   INT,
    I_VDNID         IN   INT,
    O_ISHOLIDAY     OUT  INT
) 
AS
BEGIN
  O_ISHOLIDAY := 0;
END SP_HUAWEI_GETHOLIDAY;
/
--Get the version and the service interfaces
--O_VERSION               Protocol version
--O_SP_HUAWEI_GETSERVICE  Name of the service interfaces
CREATE OR REPLACE PROCEDURE spHuaweiGetOutBoundPVersion
(
       O_VERSION               OUT VARCHAR2,
       O_SP_HUAWEI_GETSERVICE  OUT VARCHAR2
) 
AS
BEGIN
  O_VERSION := '300';
  O_SP_HUAWEI_GETSERVICE := 'SP_HUAWEI_GETSERVICE';
END spHuaweiGetOutBoundPVersion;
/
--Write back the result of callout to the user's data(Store the the result of callout to user's data)
--I_SUNIQUEID   The ID of user's data
--I_SSTATUS     Status
--I_SSERVICEID  The ID of task
--I_DEVICETYPE  The outbound device type
--I_SSUCCTEL    The phone number that is called out successfully
--I_SFAILCODE   The reason code that is returned by plaform
--I_SUBCCNO     The ID of CCS
--I_VDNID       The ID of VDN
CREATE OR REPLACE PROCEDURE SP_HUAWEI_GETOUTBOUNDRESULT
(
       I_SUNIQUEID      IN     VARCHAR2,
       I_SSTATUS        IN     VARCHAR2,
       I_SSERVICEID     IN     VARCHAR2,
       I_DEVICETYPE     IN     INT,
       I_SSUCCTEL       IN     VARCHAR2,
       I_SFAILCODE      IN     VARCHAR2,
       I_SUBCCNO        IN     INT,
       I_VDNID          IN     INT
) 
AS
BEGIN
    --If the ID of the task is null, do return.
    IF I_SSERVICEID IS NULL THEN
       RETURN;
    END IF;
    
    --If the ID of the user's data is null, do return.
    IF I_SUNIQUEID IS NULL THEN
       RETURN;
    END IF;
    
	--If callout failed, update the user's data
	IF I_SSTATUS = '0101' THEN
      --Update the data of T_HUAWEI_OBS_USERDATA(For example: outbound status, device type, the phone number of successful outbound, outbound fail code)
      UPDATE T_HUAWEI_OBS_USERDATA
      SET
      CALLCOUNT = CALLCOUNT + 1,      --The count of failed outbound
      SSTATUS = I_SSTATUS,            --outbound status
      DEVICETYPE = I_DEVICETYPE,      --device type
      SSUCCTEL = I_SSUCCTEL,          --the phone number of successful outbound
      SFAILCODE = I_SFAILCODE         --outbound fail code
      WHERE UNIQUEID = I_SUNIQUEID;
  
      --If update successfully, do commit.
      IF SQL%ROWCOUNT = 0 THEN
         RETURN;
      ELSE
         COMMIT;
      END IF;
    ELSE
	 --Update the data of T_HUAWEI_OBS_USERDATA(For example: outbound status, device type, the phone number of successful outbound, outbound fail code)
      UPDATE T_HUAWEI_OBS_USERDATA
      SET
      SSTATUS = I_SSTATUS,    --outbound status
      DEVICETYPE = I_DEVICETYPE,  --device type
      SSUCCTEL = I_SSUCCTEL,       --the phone number of successful outbound
      SFAILCODE = I_SFAILCODE       --outbound fail code
      WHERE UNIQUEID = I_SUNIQUEID;
  
       --If update successfully, do commit.
      IF SQL%ROWCOUNT = 0 THEN
         RETURN;
      ELSE
         COMMIT;
      END IF;
    END IF;
    
END SP_HUAWEI_GETOUTBOUNDRESULT;
/
--Get the interface about task, user's data, holioay, write back the result
--O_SP_HUAWEI_GETTASK            The interface of get task
--O_SP_HUAWEI_GETUSERDATA        The interface of get user's data
--O_SP_HUAWEI_GETHOLIDAY         The interface of get the holiday
--O_SP_HUAWEI_GETOUTBOUNDRESULT  The interface of write back the result
CREATE OR REPLACE PROCEDURE SP_HUAWEI_GETSERVICE
(
       O_SP_HUAWEI_GETTASK            OUT  VARCHAR2,
       O_SP_HUAWEI_GETUSERDATA        OUT  VARCHAR2,
       O_SP_HUAWEI_GETHOLIDAY         OUT  VARCHAR2,
       O_SP_HUAWEI_GETOUTBOUNDRESULT  OUT  VARCHAR2
) 
AS
BEGIN
  O_SP_HUAWEI_GETTASK := 'SP_HUAWEI_GETTASK';
  O_SP_HUAWEI_GETUSERDATA := 'SP_HUAWEI_GETUSERDATA';
  O_SP_HUAWEI_GETHOLIDAY := 'SP_HUAWEI_GETHOLIDAY';
  O_SP_HUAWEI_GETOUTBOUNDRESULT := 'SP_HUAWEI_GETOUTBOUNDRESULT';
END SP_HUAWEI_GETSERVICE;
/
--Get the task
--I_SUBCCNO   The ID of CCS
--I_VDNID     The ID of VDN
--O_TASKDATA  The result of serch task by CCSID and VDNID
CREATE OR REPLACE PROCEDURE SP_HUAWEI_GETTASK
(
       I_SUBCCNO   IN   INT,
       I_VDNID     IN   INT,
       O_TASKDATA  OUT  PG_OBS.T_DATASET
) 
AS
BEGIN
  OPEN O_TASKDATA FOR
  SELECT  
     SSERVICEID,           --The ID of task
     SDESCRIPTION,         --The description of outbound strategy
     DEVICETYPE,           --The deceive type of outbound
     SDEVICESIGN,          --The deceive name
     SCALLERNO,            --The caller Number of outbound
     SBEGINDATE,           --The begin date of task, format:yyyy-MM-dd
     SENDDATE,             --The end data of task, format:yyyy-MM-dd
     SBEGINTIME1,          --The usually start time of outbound, format: hh:mm
     SENDTIME1,            --The usually end time of outbound, format: hh:mm
     SBEGINTIME2,          --The usually start time of outbound, format: hh:mm
     SENDTIME2,            --The usually end time of outbound, format: hh:mm
     SBEGINTIME3,          --The usually start time of outbound, format: hh:mm
     SENDTIME3,            --The usually end time of outbound, format: hh:mm
     SHOLIDAYBEGINTIME1,   --The holiday start time of outbound, format: hh:mm
     SHOLIDAYENDTIME1,     --The holiday end time of outbound, format: hh:mm
     SHOLIDAYBEGINTIME2,   --The holiday start time of outbound, format: hh:mm
     SHOLIDAYENDTIME2,     ---The holiday end time of outbound, format: hh:mm
     SHOLIDAYBEGINTIME3,   --The holiday start time of outbound, format: hh:mm
     SHOLIDAYENDTIME3,     --The holiday end time of outbound, format: hh:mm
     HOLIDAYID,            --The ID of holiday
     OBSCALLINTERVAL,      --The interval of the obs get the outbound task
     OBSCALLCOUNT,         --The count of the obs get user's data every time
     OUTBOUNDTYPE,         --The type of outbound
     MAXALERTINGTIME,      --The max ringing time when a user does not answer
     PREDICTMETHOD,        --The method of predict outbound
     FORCECASTTIME,        --The pretreatment time of predict outbound
     PARA1,                
     PARA2,
     PARA3,
     PARA4,
     PARA5,
     PARA6
  FROM T_HUAWEI_TASK
  WHERE SUBCCNO = I_SUBCCNO AND VDNID = I_VDNID;
  
END SP_HUAWEI_GETTASK;
/
--Get user's data
--I_SSERVICEID     The ID of the task
--I_SUBCCNO        The ID of the CCS
--I_VDNID          The ID of the VDN
--I_BATCHCOUNT     The count of batch get data
--O_TASKDATA       The result
CREATE OR REPLACE PROCEDURE SP_HUAWEI_GETUSERDATA
(
       I_SSERVICEID     IN    VARCHAR2,
       I_SUBCCNO        IN    INT,
       I_VDNID          IN    INT,
       I_BATCHCOUNT     IN    INT,
       O_TASKDATA       OUT   PG_OBS.T_DATASET
) 
AS
BEGIN
  OPEN O_TASKDATA FOR
  SELECT
      SSERVICEID,    --The ID of the task
      UNIQUEID,     --The ID of the user
      PHONENUMBER,  --The phone number of the user
      CALLDATA      --The calldata that will be displayed to agent
  FROM T_HUAWEI_OBS_USERDATA
  WHERE SSERVICEID = I_SSERVICEID
  AND SUBCCNO = I_SUBCCNO
  AND VDNID = I_VDNID
  AND CALLCOUNT < 5
  AND ROWNUM <= I_BATCHCOUNT;
  
END SP_HUAWEI_GETUSERDATA;
/