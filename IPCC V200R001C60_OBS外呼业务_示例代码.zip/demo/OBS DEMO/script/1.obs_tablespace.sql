/*=================================================================*/
/* load this DB Script with SYSDBA                                 */
/*=================================================================*/

/*==================================================================*/
/* TABLESPACE                                                       */
/* NOTICE:modify File Path and Size before loading this script      */
/*  e.g.                                                            */
/*  Oracle Path: /oradata/db_obs/                           */
/*==================================================================*/

-- DROP TABLESPACE ts_obs INCLUDING CONTENTS AND DATAFILES;
drop tablespace ts_obs including contents and datafiles
/
create tablespace ts_obs
   DATAFILE '/oradata/db_obs/obs_dat001' SIZE 512M
   LOGGING
   ONLINE
   PERMANENT
   EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
/

-- drop user obs cascade; 
-- please set your passowrd
create user obs identified by "" default tablespace ts_obs temporary tablespace TEMP
/
grant connect to obs
/
grant resource to obs
/
grant create table to obs
/
grant create table to obs
/
grant create procedure to obs
/
grant unlimited tablespace to obs
/