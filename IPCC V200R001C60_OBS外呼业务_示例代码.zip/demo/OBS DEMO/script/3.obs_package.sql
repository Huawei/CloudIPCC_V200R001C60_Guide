/******************************************************************************/
/*                                                                            */
/*                            OBS related package                             */
/*                                                                            */
/******************************************************************************/
CREATE OR REPLACE PACKAGE PG_OBS
IS
  TYPE T_DATASET IS REF CURSOR;
END PG_OBS;
/