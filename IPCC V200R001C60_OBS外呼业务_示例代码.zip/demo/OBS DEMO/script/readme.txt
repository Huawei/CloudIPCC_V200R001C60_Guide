The instructions of running obs's scripts:
1. Modify the tablespace and username in the script "1.obs_tablespace.sql".
	1) Change the default storage path "/oradata/db_obs/" to the actual storage path in the script. And You must make sure that the actual storage path
	has been created and it can be read and written and executed by oralce's user.
	For example:
	CREATE TABLESPACE OBSDATA
	DATAFILE '/oradata/db_obs/obs_dat001' SIZE 512M
	EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
	SEGMENT SPACE MANAGEMENT AUTO;   
		
	2) Set the database user's password, for example Huawei@123. Change the temporary tablespace to the planned tablespace. After running the script,
	please remove the password from the script.
	For example:
	create user obs identified by "Huawei@123" default tablespace ts_obs temporary tablespace TEMP 
	
2. Use the oracle's system admin to login server, and run the script "1.obs_tablespace.sql".
	
3. Exit server, and use the obs to login server, and run the script "2.obs_table.sql" and "3.obs_package.sql" and "4.obs_procedure.sql" according to the order.