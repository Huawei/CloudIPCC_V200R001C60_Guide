var Config={
}
Config.Common = {
	"Language":"Chinese", //please see language/demo.agentapp.lang.string.js to see what language the demo supports
    "LogLevel":"Debug" //Debug, Info, Warn, Error
}

Config.Voice = 
{
	"SipServerIP":"127.0.0.1",
	"SipServerPort":"5060",
	"BackSipServerIP":"",
	"BackSipServerPort":"",
	"LocalIP":"127.0.0.1",
	"LocalSipPort":"6061",
	"LocalAudioPort":"6062"
}

Config.Agent = 
{
    "MainCcsIP":"127.0.0.1",
    "BackCcsIP":"",
    "CcsID":22,
    "MyID":40,
    "AutoAnswer":1,//1 for true, 0 for false
    "AutoEnterIdle":1,//1 for true, 0 for false
    "SignInEnterWork":true// ture /false
}