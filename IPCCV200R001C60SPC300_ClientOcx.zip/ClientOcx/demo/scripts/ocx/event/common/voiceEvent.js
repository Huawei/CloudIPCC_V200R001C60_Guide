// VoiceOcx  Event Handle
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

Event.VoiceOcx = {
    VoiceInitResultEvent: function (sResult) {

    },
    VoiceRegisterResultEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        if (obj.resultCode === 0) {
            VoicePhoneState.SetRegistedPhoneNumber(obj.telephone);
            VoicePhoneState.SetRegistered();
        }
    },
    VoiceDeregisterResultEvent: function (sResult) {
        VoicePhoneState.SetRegistedPhoneNumber("");
        VoicePhoneState.SetUnregistered();
    },
    VoiceTalkOutgoingEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        VoicePhoneState.SetCallingPhoneNumber(obj.callee);
        VoicePhoneState.SetCallID(obj.callid);
    },
    VoiceTalkRingBackEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        VoicePhoneState.SetCallID(obj.callid);
        VoicePhoneState.SetAlerting();
    },
    VoiceTalkAlertingEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        VoicePhoneState.SetCallID(obj.callid);
        VoicePhoneState.SetCallingPhoneNumber(obj.caller);
        VoicePhoneState.SetAlerting();
    },
    VoiceSrtpResultEvent: function (sResult) {

    },
    VoiceTalkConnectedEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        VoicePhoneState.SetTalking();
    },
    VoiceTalkReleaseEvent: function (sResult) {
        var obj = JSON.parse(sResult);
        VoicePhoneState.SetCallingPhoneNumber(''); //there is no call now
        VoicePhoneState.SetReleased();
    },
    VoiceSipInfoArrivedEvent: function (sResult) {

    },
	VoiceStartCallResultEvent: function(sResult)
	{
		
	}
}