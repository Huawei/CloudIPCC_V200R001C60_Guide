// event excute method
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var AgentEventNotPrintElems =
{
	OnReceiveChat: [1],
	OnReceiveChatEx: [1],
	OnDelCallInConf: [1, 2],
	OnCallerCalledInfoArrived: [2, 3],
	OnPrepareJoinMultimediaConf: [4]
};
var VoiceEventNotPrintJSONElems = 
{
	VoiceRegisterResultEvent: ["name", "telephone"],
	VoiceDeregisterResultEvent: ["name", "telephone"],
	VoiceTalkOutgoingEvent: ["callee"],
	VoiceTalkRingBackEvent: ["callee"],
	VoiceTalkAlertingEvent: ["caller"],
	VoiceTalkConnectedEvent: ["callee", "caller"],
	VoiceTalkReleaseEvent: ["callee", "caller"],
	VoiceSipInfoArrivedEvent: ["message"]
};
var ConferenceEventNotPrintJSONElems = 
{
	MessageArrivedEvent: ["data"],
	FileTranProgressEvent: ["fileName"],
	FileTranOverEvent: ["fileName"],
	FileArrivedEvent: ["fileName"]
};

// !function ICSClientOcx event excute
function ICSClientEventHandle(sEventName)
{
	var _argumentsInfo = arguments[1];
	if("" != _argumentsInfo)
	{

		var obj = JSON.parse(_argumentsInfo);

		if(-1 != _argumentsInfo.indexOf("chatContent"))
		{
			obj.event.content.chatContent = "******";
		}
		if(-1 != _argumentsInfo.indexOf("confInfo"))
		{
			obj.event.content.confInfo = "******";
		}	
		_argumentsInfo = JSON.stringify(obj);
	}	
	
	INFO_LOG_METHOD("ICSClientOcx", "Event:" + sEventName+ ",start. eventInfo:" + _argumentsInfo);
	
	if(isNull(sEventName) )
	{
		alert("event name is null.");
		return;
	}
	if("function" === typeof(Event["ICSClientOcx"][sEventName]) )
	{
		Event["ICSClientOcx"][sEventName](arguments[1]);
	}
	
	INFO_LOG_METHOD("ICSClientOcx", "Event:"+sEventName+ ",end. " );
}

// !function AgentOcx interfaces excute
function AgentEventHandle(sEventName)
{
	var _argumentsInfo = "";
	var _phoneNumber = "";
	for(var i=0; i<arguments.length;++i)
	{
		if(UTIL.isInArray(AgentEventNotPrintElems[sEventName], i))
		{
			if(("OnDelCallInConf" == sEventName) || ("OnCallerCalledInfoArrived" == sEventName))
			{
				_phoneNumber = arguments[i].substr(arguments[i].length/2);
                _argumentsInfo += "***" + _phoneNumber + ",";
			}
			else
			{
				_argumentsInfo += "******" + ",";
			}	
			continue;
		}
		_argumentsInfo += arguments[i]+",";
	}

	if("" != _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}
	
	INFO_LOG_METHOD("AgentOcx", "Event:"+sEventName+ ",start. eventInfo:"+_argumentsInfo );
	
	if(isNull(sEventName) )
	{
		alert("event name is null.");
		return;
	}
	
	var _result = null;
	if("function" === typeof(Event["AgentOcx"][sEventName]) )
	{
		if(1===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName]();
		}
		else if(2===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1]);
		}
		else if(3===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1],arguments[2]);
		}
		else if(4===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1],arguments[2],arguments[3]);
		}
		else if(5===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);
		}
		else if(7===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6]);
		}
		else if(14===arguments.length)
		{
			_result = Event["AgentOcx"][sEventName](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6],
											        arguments[7],arguments[8],arguments[9],arguments[10],arguments[11],arguments[12],
													arguments[13]);
		}
		else
		{
			alert("arguments length is too long.");
		}
	}
	
	INFO_LOG_METHOD("AgentOcx", "Event:"+sEventName+ ",end. " );
	
	return _result;
}

// !function ConferenceOcx event excute
function ConferenceEventHandle(sEventName)
{
	var _argumentsInfo = arguments[1];
	if("" != _argumentsInfo)
	{
		if(ConferenceEventNotPrintJSONElems[sEventName])
		{
			var item = null;
			var items = ConferenceEventNotPrintJSONElems[sEventName];
			var obj = JSON.parse(_argumentsInfo);
			for(var i=0; i<items.length;i++)
			{
				item = items[i];
				obj[item] = "******";
			}	
			_argumentsInfo = JSON.stringify(obj);
			_argumentsInfo = recoverJSONForm(_argumentsInfo);
		}
	}	

	INFO_LOG_METHOD("ConferenceOcx", "Event:"+sEventName+ ",start. eventInfo:"+_argumentsInfo);
	
	if(isNull(sEventName) )
	{
		alert("event name is null.");
		return;
	}
	if("function" === typeof(Event["ConferenceOcx"][sEventName]) )
	{
		Event["ConferenceOcx"][sEventName](arguments[1]);
	}
	
	INFO_LOG_METHOD("ConferenceOcx", "Event:"+sEventName+ ",end. " );
}



// !function VoiceOcx interfaces excute
function VoiceEventHandle(sEventName)
{
	var _argumentsInfo = arguments[1];
	if("" != _argumentsInfo)
	{
		if(VoiceEventNotPrintJSONElems[sEventName])
		{
			var item = "";
			var _phoneNumber = "";
			var items = VoiceEventNotPrintJSONElems[sEventName];
			var obj = JSON.parse(_argumentsInfo);
			for(var i=0; i<items.length;i++)
			{
				item = items[i];
				if("message" != item)
				{
					_phoneNumber = obj[item].substr(obj[item].length/2);
					obj[item] = "***" + _phoneNumber;
				}
				else
				{
					obj[item] = "******";
				}	
			}	
			_argumentsInfo = JSON.stringify(obj);
			_argumentsInfo = recoverJSONForm(_argumentsInfo);
		}
	}	

	INFO_LOG_METHOD("VoiceOcx", "Event:"+sEventName+ ",start. eventInfo:"+_argumentsInfo);
	
	if(isNull(sEventName) )
	{
		alert("event name is null.");
		return;
	}
	if("function" === typeof(Event["VoiceOcx"][sEventName]) )
	{
		Event["VoiceOcx"][sEventName](arguments[1]);
	}
	
	INFO_LOG_METHOD("VoiceOcx", "Event:"+sEventName+ ",end. " );
}