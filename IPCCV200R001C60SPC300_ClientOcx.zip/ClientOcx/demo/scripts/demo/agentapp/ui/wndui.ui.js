//WndUiUIClass constructor
function WndUiUIClass() {

}

//WndUiUIClass methods define
WndUiUIClass.prototype = {
    UpdateWindowList: function () {
        var selectID = document.getElementById('AgentAppDemo.WindowList');
        var wndList = WndUiState.GetWndList();
        
        // first remove all
        selectID.options.length = 0;

        //update the window list
        for (var i=0; i < wndList.length; i++){
            var varItem = new Option(wndList[i].title, wndList[i].hwnd);
            selectID.options.add(varItem);
        }
    },
    RemoveWindowList: function () {
        var selectID = document.getElementById('AgentAppDemo.WindowList');
        for (var i = 0; i < selectID.options.length; i++) {
            //first, destory the window resource
            WndUiExcute('Destroy', selectID.options[i].value)
        }
        //remove all
        selectID.options.length = 0;
    }
}