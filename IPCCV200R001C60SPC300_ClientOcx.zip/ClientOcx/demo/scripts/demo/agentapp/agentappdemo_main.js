var AgentAppDemoApplication = new AgentAppDemo();
var VoicePhoneState = new VoiceStateClass();
var AgentState = new AgentStateClass();
var ConferenceState = new ConferenceStateClass();
var WndUiState = new WndUiStateClass();
var AgentUI = new AgentUIClass();
var VoicePhoneUI = new VoiceUIClass();
var ConferenceUI = new ConferenceUIClass();
var WndUiUI = new WndUiUIClass();
var LanguagePage = new LanguagePageClass();
var UserState = new UserStateClass();
var I18N = new I18NClass();
var AgentAppNotPrintElems = 
{
	Login: [2, 4],
    Register: [1, 2],
    SendChat: [1],
    SendFile: [1],
    ReceiveFile: [2]
};

function CopyValueToInput(strValue, inputID) {
    document.getElementById(inputID).value = strValue;
}

//load agent config from config file
function LoadAgentConfig()
{
    //load agent config
    CopyValueToInput(Config.Agent["MainCcsIP"], "AgentAppDemo.MainCcsIP");
    CopyValueToInput(Config.Agent["AutoAnswer"], "AgentAppDemo.AutoAnswer");
    CopyValueToInput(Config.Agent["AutoRelease"], "AgentAppDemo.AutoRelease");
    CopyValueToInput(Config.Agent["AutoEnterIdle"], "AgentAppDemo.AutoEnterIdle");
    CopyValueToInput(Config.Agent["MyID"], "AgentAppDemo.AgentProgID");
	
	//load agent voice config
	CopyValueToInput(Config.Voice["SipServerIP"], "AgentAppDemo.SipServerIP");
	CopyValueToInput(Config.Voice["SipServerPort"], "AgentAppDemo.SipServerPort");
	CopyValueToInput(Config.Voice["LocalIP"], "AgentAppDemo.LocalIP");
	CopyValueToInput(Config.Voice["LocalSipPort"], "AgentAppDemo.LocalSipPort");
	CopyValueToInput(Config.Voice["LocalAudioPort"], "AgentAppDemo.LocalAudioPort");
	var backSipserverInfo = Config.Voice["BackSipServerIP"];
	backSipserverInfo = backSipserverInfo.replace(/^\s+|\s+$/g,'');
	if (backSipserverInfo !==''){
		backSipserverInfo = '[{"ip":"' + Config.Voice["BackSipServerIP"] + '","port":"' + Config.Voice["BackSipServerPort"] + '"}]';
	}
	//auto config voice ocx serverInfo localInfo
    VoiceExcute("SetSipServerInfo", Config.Voice["SipServerIP"], Config.Voice["SipServerPort"], backSipserverInfo); //set the backServerInfo default to empty string
    VoiceExcute("SetLocalInfo", Config.Voice["LocalIP"], Config.Voice["LocalSipPort"], Config.Voice["LocalAudioPort"]);
	
	//change the page text according to the language config
	var langobj = LanguagePage.GetLanguagePage(Config.Common['Language']);
	I18N.SwitchI18N(langobj);
}

// !function UserAppDemo interfaces excute
function AgentAppDemoExcute(sInterfaceName)
{
	var _argumentsInfo = "";
    var _phoneNumber = "";
	for(var i=0; i<arguments.length;++i)
	{
		if(UTIL.isInArray(AgentAppNotPrintElems[sInterfaceName], i))
		{
            if(("Register" == sInterfaceName) && (1 == i))
            {
                _phoneNumber = arguments[1].substr(arguments[1].length/2);
                _argumentsInfo += "***" + _phoneNumber + ","; 
            }                
            else if(("Login" == sInterfaceName) && (4 == i))
            {
                _phoneNumber = arguments[4].substr(arguments[4].length/2);
                _argumentsInfo += "***" + _phoneNumber + ",";
            }
            else
            {
		        _argumentsInfo += "******" + ",";
            }    
			continue;
		}
		_argumentsInfo += arguments[i] + ",";
	}
	if("" !== _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}

    INFO_LOG_METHOD("AgentAppDemo", "Interface:" + sInterfaceName + ", start.arguments:" + _argumentsInfo);
	
	if(isNull(sInterfaceName) )
	{
		alert(sInterfaceName + " interface name is null.");
		return;
	}
    if ("function" !== typeof (AgentAppDemoApplication[sInterfaceName]))
	{
		alert(sInterfaceName + " is not function.");
	}
	
	var _result = null;
	
	if(1 === arguments.length)
	{
	    _result = AgentAppDemoApplication[sInterfaceName]();
	}
	else if(2 === arguments.length)
	{
	    _result = AgentAppDemoApplication[sInterfaceName](arguments[1]);
	}
	else if(3 === arguments.length)
	{
	    _result = AgentAppDemoApplication[sInterfaceName](arguments[1], arguments[2]);
	}
	else if(4 === arguments.length)
	{
	    _result = AgentAppDemoApplication[sInterfaceName](arguments[1], arguments[2], arguments[3]);
	}
	else if(5 === arguments.length)
	{
	    _result = AgentAppDemoApplication[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
	}
	else
	{
		alert("arguments length is too long.");
	}
    try
    {
        INFO_LOG_METHOD("AgentAppDemo", "Interface:" + sInterfaceName + ",end.result:" + _result);
        
    } catch (e) {

    }
	
	return _result;
}