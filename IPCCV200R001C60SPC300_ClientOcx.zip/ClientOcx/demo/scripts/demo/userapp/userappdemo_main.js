var UserDemoApplication = new UserAppDemo();
var VoicePhoneState = new VoiceStateClass();
var ConferenceState = new ConferenceStateClass();
var WndUiState = new WndUiStateClass();
var ICSClientState = new ICSClientStateClass();
var VoicePhoneUI = new VoiceUIClass();
var ConferenceUI = new ConferenceUIClass();
var WndUiUI = new WndUiUIClass();
var ICSClientUI = new ICSClientUIClass();
var LanguagePage = new LanguagePageClass();
var UserState = new UserStateClass();
var I18N = new I18NClass();
var UserAppNotPrintElems = 
{
    SendChatMessage: [1],
    Call: [3],
    SendFile: [1],
    ReceiveFile: [2]
};

function LoadUserConfig() {
    if (UserConfig === undefined || UserConfig === null) {
        alert("UserConfig lost, did you deleted it?");
        return;
    }
    //1�� invoke icsclient method ,SetServerInfo
    var IcsServerInfoObj = {};
    IcsServerInfoObj.ip = UserConfig.ICSClient["icsgatewayIp"];
    IcsServerInfoObj.port = UserConfig.ICSClient["icsgatewayPort"];
    IcsServerInfoObj.name = UserConfig.ICSClient["icsgatewayName"];
    IcsServerInfoObj.vdnId = UserConfig.ICSClient["VdnID"];
    if (UserConfig.ICSClient["sslEnable"]) {
        IcsServerInfoObj.sslEnable = 1;
    }
    else {
        IcsServerInfoObj.sslEnable = 0;
    }
    var strServerInfo = JSON.stringify(IcsServerInfoObj);
    ICSClientExcute("SetServerInfo", strServerInfo);
	var backSipserverInfo = UserConfig.Voice["BackSipServerIP"];
	backSipserverInfo = backSipserverInfo.replace(/^\s+|\s+$/g,'');
	if (backSipserverInfo !==''){
		backSipserverInfo = '[{"ip":"' + UserConfig.Voice["BackSipServerIP"] + '","port":"' + UserConfig.Voice["BackSipServerPort"] + '"}]';
	}
    //3��auto config voice ocx serverInfo localInfo
    VoiceExcute("SetSipServerInfo", UserConfig.Voice["SipServerIP"], UserConfig.Voice["SipServerPort"], backSipserverInfo); //set the backServerInfo default to empty string
    VoiceExcute("SetLocalInfo", UserConfig.Voice["LocalIP"], UserConfig.Voice["LocalSipPort"], UserConfig.Voice["LocalAudioPort"]);
	
	//4 change the page text according to the language config
	var langobj = LanguagePage.GetLanguagePage(UserConfig.Common['Language']);
	I18N.SwitchI18N(langobj);
}

// !function UserAppDemo interfaces excute
function UserAppDemoExcute(sInterfaceName)
{
	var _argumentsInfo = "";
	for(var i=0; i<arguments.length;++i)
	{
        if(UTIL.isInArray(UserAppNotPrintElems[sInterfaceName], i))
        {
            _argumentsInfo += "******" + ",";
            continue;
        }
		_argumentsInfo += arguments[i]+",";
	}
	if("" !== _argumentsInfo)
	{
		_argumentsInfo = _argumentsInfo.substr(0, _argumentsInfo.length-1);
	}

    INFO_LOG_METHOD("UserDemoApplication", "UserAppDemo Interface:" + sInterfaceName + ", start.arguments:" + _argumentsInfo);
	
	if(isNull(sInterfaceName) )
	{
		alert(sInterfaceName + " interface name is null.");
		return;
	}
    if ("function" !== typeof (UserDemoApplication[sInterfaceName]))
	{
		alert(sInterfaceName + " is not function.");
	}
	
	var _result = null;
    var _resultInfo = null;
	
	if(1 === arguments.length)
	{
	    _result = UserDemoApplication[sInterfaceName]();
        _resultInfo = _result;
        if("GetCallbackPhoneNumber" == sInterfaceName)
        {
            _resultInfo = "***" + _resultInfo.substr(_resultInfo.length/2);
        }    
	}
	else if(2 === arguments.length)
	{
	    _result = UserDemoApplication[sInterfaceName](arguments[1]);
        _resultInfo = _result;
	}
	else if(3 === arguments.length)
	{
	    _result = UserDemoApplication[sInterfaceName](arguments[1], arguments[2]);
        _resultInfo = _result;
	}
	else if(4 === arguments.length)
	{
	    _result = UserDemoApplication[sInterfaceName](arguments[1], arguments[2], arguments[3]);
        _resultInfo = _result;
	}
	else if(5 === arguments.length)
	{
	    _result = UserDemoApplication[sInterfaceName](arguments[1], arguments[2], arguments[3], arguments[4]);
        _resultInfo = _result;
        if(("OpenDialog" == sInterfaceName) && ("GetCallbackPhoneNumber" == arguments[1]))
        {
            _resultInfo = "***" + _resultInfo.substr(_resultInfo.length/2);
        }    
	}
	else
	{
		alert("arguments length is too long.");
	}
	try
    {
        INFO_LOG_METHOD("UserDemoApplication", "UserAppDemo Interface:" + sInterfaceName + ",end.result:" + _resultInfo);    

	}catch(e)
	{
		
	}
	return _result;
}
