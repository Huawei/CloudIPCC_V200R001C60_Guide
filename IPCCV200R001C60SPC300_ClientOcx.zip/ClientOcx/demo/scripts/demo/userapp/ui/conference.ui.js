//notice
/*
*	ConferenceUI must implement following interface
*   UpdateWhenConfMemberEntered
*   UpdateWhenConfMemberLeaved
*   UpdateWhenConfMeetingTeminated
*   UpdateWhenVideoDeviceOpened
*   UpdateWhenVideoDeviceClosed
*/
//ConferenceUIClass constructor
function ConferenceUIClass() {
    this.AddToConfMemberList = function (userID) {
        var userLink = "<a href=\"#\" title=\"" + userID + "\" id=\"user_" + userID + "\">" + userID + " </a>";
        document.getElementById("UserAppDemo.Conference.UserList").innerHTML += userLink;
    }
    this.RemoveFromConfMemberList = function (userID) {
        var elem = document.getElementById('user_' + userID);
        if (elem) {
            elem.parentNode.removeChild(elem);
        }
    }
    this.ClearConfMemberList = function () {
        document.getElementById("UserAppDemo.Conference.UserList").innerHTML = "";
    }
}

//VoiceUIClass methods define
ConferenceUIClass.prototype = {
    UpdateWhenConfMemberEntered: function (userID, userRole) {
        this.AddToConfMemberList(userID);
    },
    UpdateWhenConfMemberLeaved: function (userID) {
        this.RemoveFromConfMemberList(userID);
    },
    UpdateWhenJoinConfSuccess: function (resultCode) {
        UserAppDemoExcute("ReportJoinMeetingResult", 0, resultCode);
        UserAppDemoExcute("CreateDesktopShareWindow");
        UserState.SetIsLocalVideoOpened(false);
		document.getElementById("UserAppDemo.OpenLocalVideo").style.display = "inline";
		document.getElementById("UserAppDemo.CloseLocalVideo").style.display = "none";
		document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "none";
		document.getElementById('UserAppDemo.SetVideoParam').disabled = true;
    },
    UpdateWhenJoinConfFailed: function (resultCode) {
        UserAppDemoExcute("ReportJoinMeetingResult", 1, resultCode);
    },
    UpdateWhenConfMeetingTeminatedSuccess: function (confID) {
        this.ClearConfMemberList();
        WndUiUI.RemoveWindowList();
        UserAppDemoExcute("ReportMeetingTeminated");
        ConferenceState.RemoveAllConfMembers();
        ConferenceState.SetCurrentJoinedConfID("");
        ConferenceState.SetJoinedConfInfo("");
        ConferenceState.RemoveAllConfVideoDevices();
        UserState.SetIsLocalVideoOpened(false);
		document.getElementById("UserAppDemo.OpenLocalVideo").style.display = "inline";
		document.getElementById("UserAppDemo.CloseLocalVideo").style.display = "none";
		document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "none";
		document.getElementById('UserAppDemo.SetVideoParam').disabled = true;
    },
    UpdateWhenConfMeetingTeminatedFailed: function (confID) {
        //no need to do anything
    },
    UpdateWhenVideoDeviceOpened: function (userID, deviceID) {
        UserAppDemoExcute("CreateVideoDeviceWindow", userID, deviceID);
        if (parseInt(userID) === ConferenceState.GetSelfUserID()) {
            UserState.SetIsLocalVideoOpened(true);
            document.getElementById("UserAppDemo.OpenLocalVideo").style.display = "none";
			document.getElementById("UserAppDemo.CloseLocalVideo").style.display = "inline";
            document.getElementById('UserAppDemo.SetVideoParam').disabled = false;
        }
    },
    UpdateWhenVideoDeviceClosed: function (userID, deviceID) {
        var hwnd = 0;
        var wndList = WndUiState.GetWndList();
        for (var i = 0; i < wndList.length; i++) {
            if (wndList[i].title.indexOf(userID + "_" + deviceID) > 0) {
                hwnd = wndList[i].hwnd;
                break;
            }
        }

        if (hwnd === 0) {
            INFO_LOG_METHOD("ConferenceUI", " Warning!!!! close a video device ,but it is not in the list!")
        }

        UserAppDemoExcute("CloseVideoDeviceWindow", userID, deviceID, hwnd);
        if (parseInt(userID) === ConferenceState.GetSelfUserID()) {
            UserState.SetIsLocalVideoOpened(false);
            document.getElementById("UserAppDemo.OpenLocalVideo").style.display = "inline";
			document.getElementById("UserAppDemo.CloseLocalVideo").style.display = "none";
            document.getElementById('UserAppDemo.SetVideoParam').disabled = true;
        }
    },
    UpdateWhenFileArrived: function (fileHandle, fileName, fileSize) {
        document.getElementById('UserAppDemo.ReceiveFile.FileHandle').value = fileHandle;
        document.getElementById('UserAppDemo.ReceiveFile.FileName').value = fileName;
        document.getElementById('UserAppDemo.ReceiveFile.FileName').style.backgroundColor = "yellow";
    },
    UpdateWhenFileTransRecvProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId, resultCode) {
        document.getElementById('UserAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv complete:' + fileProgress + '%;ResultCode:' + resultCode;

    },
    UpdateWhenFileTransSendProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId, resultCode) {
        document.getElementById('UserAppDemo.Conference.FileTranSendProgress').innerHTML = 'send complete:' + fileProgress + '%;ResultCode:' + resultCode;
        document.getElementById('UserAppDemo.SendFile.FileHandle').value = fileHandle;
    },
    UpdateWhenFileTransSendOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        document.getElementById('UserAppDemo.SendFile.FileHandle').value = fileHandle;
        document.getElementById('UserAppDemo.Conference.FileTranSendProgress').innerHTML = 'send complete!';
    },
    UpdateWhenFileTransSendOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {
        document.getElementById('UserAppDemo.SendFile.FileHandle').value = fileHandle;
        document.getElementById('UserAppDemo.Conference.FileTranSendProgress').innerHTML = 'send failed!' + ';ResultCode:' + resultCode;
    },
    UpdateWhenFileTransRecvOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        document.getElementById('UserAppDemo.ReceiveFile.FileHandle').value = '';
        document.getElementById('UserAppDemo.ReceiveFile.FileName').value = '';
        document.getElementById('UserAppDemo.ReceiveFile.FileName').style.backgroundColor = "white";
        document.getElementById('UserAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv complete!';
    },
    UpdateWhenFileTransRecvOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {

        document.getElementById('UserAppDemo.ReceiveFile.FileHandle').value = '';
        document.getElementById('UserAppDemo.ReceiveFile.FileName').value = '';
        document.getElementById('UserAppDemo.ReceiveFile.FileName').style.backgroundColor = "red";
        document.getElementById('UserAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv failed!' + ';ResultCode:' + resultCode;
    },
    UpdateWhenDesktopShareSizeShow: function () {
		//when the other user start share screen, change the control state back
        document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "none";
    },
	UpdateWhenSetOperationPrivilegeState: function(action, privilegeType, userId){
		if (privilegeType === "remotectl"){
			if (action === "delete")
			{
				if (parseInt(userId) !== ConferenceState.GetSelfUserID() && ConferenceState.GetIsSharingDesktop())
				{
					document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "inline";
					document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "none";
				}
			}
			else if (action === "add"){
				if (parseInt(userId) !== ConferenceState.GetSelfUserID() && ConferenceState.GetIsSharingDesktop())
				{
					document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "none";
					document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "inline";
				}
			}
		}
	},
	UpdateWhenStartShareScreenResult: function(resultCode){
		document.getElementById("UserAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("UserAppDemo.StopRemoteCtrl").style.display = "none";
	}

}