//ICSClientUIClass constructor

function ICSClientUIClass() {
    this.GetUserStatus = function () {
        var talkingStr = "";
        var queueingStr = "";
		var alertingStr = "";
		
        if (ICSClientState.GetWebChatCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED) {
            talkingStr += "webchat-";
        }
        else if (ICSClientState.GetWebChatCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING) {
            queueingStr += "webchat-";
        }
		else if (ICSClientState.GetWebChatCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING) {
            alertingStr += "webchat-";
        }
		
        if (ICSClientState.GetClickCallCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED) {
            talkingStr += "clickcall-";
        }
        else if (ICSClientState.GetClickCallCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING) {
            queueingStr += "clickcall-";
        }
		else if (ICSClientState.GetClickCallCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING) {
            alertingStr += "clickcall-";
        }
		
        if (ICSClientState.GetCallBackCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED) {
            talkingStr += "callback";
        }
        else if (ICSClientState.GetCallBackCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING) {
            queueingStr += "callback";
        }
		else if (ICSClientState.GetCallBackCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING) {
            alertingStr += "callback";
        }
		
		if (ICSClientState.GetVCCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED) {
            talkingStr += "vccall";
        }
        else if (ICSClientState.GetVCCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING) {
            queueingStr += "vccall";
        }
		else if (ICSClientState.GetVCCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING) {
            alertingStr += "vccall";
        }
        //return the status object
        var obj = new Object();
        obj.hasTalking = false;
        obj.hasQueueing = false;
		obj.hasAlerting = false;
        if ( talkingStr !== "" ) {
            obj.hasTalking = true;
        }
        if ( queueingStr !== "" ) {
            obj.hasQueueing = true;
        }
		if ( alertingStr !== "" ) {
            obj.hasAlerting = true;
        }
        obj.talkingstr = "<font color='green'>Talking-" + talkingStr + "</font>";
        obj.queueingstr = "<font color='red'>Queueing-" + queueingStr + "</font>";
		obj.alertingstr = "<font color='blue'>Alerting-" + alertingStr + "</font>";
        return obj;
    }
    this.UpdateStatusMessage = function () {
        var userStatus = this.GetUserStatus();
        var htmlInner = "";
        if (userStatus.hasTalking) {
            htmlInner += userStatus.talkingstr;
        }
        if (userStatus.hasQueueing) {
            htmlInner += userStatus.queueingstr;
        }
		if (userStatus.hasAlerting){
			htmlInner += userStatus.alertingstr;
		}
        if (!(userStatus.hasTalking) && !(userStatus.hasQueueing) && !(userStatus.hasAlerting)) {
            var userAppState = ICSClientState.GetUserAppState();
            // if there is no call and queueing now, update current uvid and callid to be empty
            ICSClientState.SetCurrentCallID("");
            ICSClientState.SetCurrentCallUVID(-1);
            if (userAppState === ICSCLIENT_USER_STATE.ICS_USER_STATE_LOGIN) {
                htmlInner = "<font color='blue'>" + 'login' + "</font>";
            }
            else if (userAppState === ICSCLIENT_USER_STATE.ICS_USER_STATE_LOGIN) {
                htmlInner = "<font color='black'>" + 'no login' + "</font>";
            }
            else {
                ERROR_LOG_METHOD("ICSClientUI", "There should not be such a state here!");
            }
			//when all all is over , teminate the meeting that the user has joined
            if (ConferenceState.GetCurrentJoinedConfID() !== ""){
                ConferenceExcute("TerminateConf");
            }

        }

        document.getElementById("UserAppDemo.Status").innerHTML = htmlInner;
    }
}

//methods declare
ICSClientUIClass.prototype = {
    UpdateWhenUserLogin: function () {
        document.getElementById("UserAppDemo.Status").innerHTML = "<font color='blue'>" + 'login' + "</font>";
        document.getElementById("UserAppDemo.Login").style.display = "none";
        document.getElementById("UserAppDemo.Logout").style.display = "inline";
    },
    UpdateWhenUserLogout: function () {
        document.getElementById("UserAppDemo.Status").innerHTML = "<font color='black'>" + 'no login' + "</font>";
        document.getElementById("UserAppDemo.Login").style.display = "inline";
        document.getElementById("UserAppDemo.Logout").style.display = "none";
    },
    UpdateWhenUserQueueing: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenUserQueueingEnd: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenWebChatCallBegin: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenWebChatCallEnd: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenClickCallCallBegin: function () {
        this.UpdateStatusMessage();
        VoiceExcute("AnonymousCall", UserConfig.Voice.AnnonymousCard, ICSClientState.GetAnonymousCallee());
    },
    UpdateWhenClickCallCallEnd: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenCallBackCallBegin: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenCallBackCallEnd: function () {
        this.UpdateStatusMessage();
    },
	UpdateWhenVCCallBegin: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenVCCallEnd: function () {
        this.UpdateStatusMessage();
    },
    UpdateWhenChatContentCleared: function () {
        document.getElementById("UserAppDemo.ChatTextBox").innerText = "";
    },
    UpdateWhenChatContentReceived: function () {
        document.getElementById("UserAppDemo.ChatTextBox").innerText = ICSClientState.GetChatContent();
    },
    UpdateWhenChatContentSent: function () {
        document.getElementById("UserAppDemo.ChatTextBox").innerText = ICSClientState.GetChatContent();
        document.getElementById("UserAppDemo.ChatMessage").value = "";
    },
    UpdateWhenPrepareJoinMeeting: function (sConfInfo) {
        //automatically fire the action to join conf
        ConferenceExcute("JoinConf", sConfInfo);
    }
}