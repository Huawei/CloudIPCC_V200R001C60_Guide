//WndUIStateClass constructor
function WndUiStateClass() {

}

WndUiStateClass.prototype = {
    GetWndList: function () {
        var wndinfo = WndUiExcute('GetWndsInfo');
        var obj = JSON.parse(wndinfo);
        return obj.wndInfos;
    }
}