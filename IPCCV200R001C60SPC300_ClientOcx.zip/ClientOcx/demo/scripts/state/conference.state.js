//ConferenceStateClass constructor
function ConferenceStateClass() {
    this._currentJoinedConfID = "";
    this._joinedConfInfo = "";
    this._selfUserID = "";
    //confMemberList contains memberInfo Object, object which has fields like below;{userID:"", userFlag:"", userRole:""}
    this._confMemberList = [];
    //confVideoList contains opened video device info object, the object has fields like below: {userID:"", deviceID:""}
    this._confVideoDeviceList = [];
    this._desktopShareHwnd = "";
	this._desktopShareDisplaySet = {x:1,y:1};// object {"X":, "Y":}
	this._desktopShareControlUserID = "";
	this._isSharingDesktop = false;
    this.SetCurrentJoinedConfID = function (confID) {
        this._currentJoinedConfID = confID;
    }
    this.GetCurrentJoinedConfID = function () {
        return this._currentJoinedConfID;
    }
    this.SetJoinedConfInfo = function (confInfo) {
        this._joinedConfInfo = confInfo;
    }
    this.GetJoinedConfInfo = function () {
        return this._joinedConfInfo;
    }
    this.SetSelfUserID = function (userid) {
        this._selfUserID = userid;
    }
    this.GetSelfUserID = function () {
        return parseInt(this._selfUserID);
    }
    this.IsSelfUser = function (userId) {
        return (parseInt(userId) === parseInt(this._selfUserID));
    }
    this.SetDesktopShareHwnd = function (hwnd) {
        this._desktopShareHwnd = hwnd;
    }
    this.GetDesktopShareHwnd = function () {
        return this._desktopShareHwnd;
    }
    this.SetDesktopShareDisplaySet = function (obj) {
        this._desktopShareDisplaySet = obj;
		this.SetDesktopShareControlUser('');
		//when user receives such size event, he can't be the sharing user
		this.SetIsSharingDesktop(false);
        ConferenceUI.UpdateWhenDesktopShareSizeShow();
    }
    this.GetDesktopShareDisplaySet = function () {
        return this._desktopShareDisplaySet;
    }
	this.GetDesktopShareControlUser = function () {
        return parseInt(this._desktopShareControlUserID);
    }
    this.SetDesktopShareControlUser = function (option) {
        this._desktopShareControlUserID = option;
    }
	this.GetIsSharingDesktop = function () {
        return this._isSharingDesktop;
    }
    this.SetIsSharingDesktop = function (option) {
        this._isSharingDesktop = option;
    }
    this.AddConfMember = function (userID, userFlag, userRole) {
        //first see if the user is in the list
        for (var i = 0; i < this._confMemberList.length; i++) {
            if (parseInt(this._confMemberList[i].userID) === parseInt(userID)) {
                // should return
                return false;
            }
        }

        //add confMember to the list 
        var memberInfo = new Object();
        memberInfo.userID = userID;
        memberInfo.userFlag = userFlag;
        memberInfo.userRole = userRole;
        this._confMemberList.push(memberInfo);
        return true;
    }
    this.GetTalkingUser = function()
    {
        //iterate the confMemberList to find corresponding user
        for (var i = 0; i < this._confMemberList.length; i++) {
            if (parseInt(this._confMemberList[i].userID) == this.GetSelfUserID()) {
                continue;
            }
            return this._confMemberList[i].userID;
        }
    }
    this.IsInConfMemberList = function (userID) {
        //iterate the confMemberList to find corresponding user
        for(var i=0; i < this._confMemberList.length; i++){
            if ( parseInt(this._confMemberList[i].userID) === parseInt(userID) ){  
                return true;
            }
        }
        //not found
        return false;
    }
    this.RemoveConfMember = function (userID) {
        if (this.IsInConfMemberList(userID)) {
            for (var i = 0; i < this._confMemberList.length; i++) {
                if (parseInt(this._confMemberList[i].userID) === parseInt(userID)) {
                    this._confMemberList.splice(i, 1); // delete the object
                    return true;
                }
            }
        }
        else {
            INFO_LOG_METHOD("ConferenceState", "ConferenceState, Warning!!!!! trying to remove user not in the list");
            return false;
        }
    }

    this.RemoveAllConfMembers = function () {
        this._confMemberList.splice(0, this._confMemberList.length); //delete all conf members
        return true;
    }

    this.GetConfMemberList = function () {
        return this._confMemberList;
    }

    this.AddConfVideoDevice = function (userID, deviceID) {
        if (this.IsDeviceInVideoDeviceList(userID, deviceID)) {
            INFO_LOG_METHOD("ConferenceState", "ConferenceState, Warning!!!!! video device already in the device!");
            return false;
        }
        var deviceInfo = new Object();
        deviceInfo.userID = userID;
        deviceInfo.deviceID = deviceID;
        //add object to the list
        this._confVideoDeviceList.push(deviceInfo);
        return true;
    }

    this.IsDeviceInVideoDeviceList = function (userID, deviceID) {
        for (var i = 0; i < this._confVideoDeviceList.length; i++) {
            if (parseInt(this._confVideoDeviceList[i].userID) === parseInt(userID) && parseInt(this._confVideoDeviceList[i].deviceID) === parseInt(deviceID)) {
                return true;
            }
        }
        return false;
    }

    this.RemoveConfVideoDevice = function (userID, deviceID) {
        if (this.IsDeviceInVideoDeviceList(userID, deviceID)) {
            for (var i = 0; i < this._confVideoDeviceList.length; i++) {
                if (parseInt(this._confVideoDeviceList[i].userID) === parseInt(userID) && parseInt(this._confVideoDeviceList[i].deviceID) === parseInt(deviceID)) {
                    this._confVideoDeviceList.splice(i, 1); // remove specifed object
                    return true;
                }
            }
        }
        else {
            INFO_LOG_METHOD("ConferenceState", "ConferenceState, Warning!!!!! trying to remove video device not in the list");
            return false;
        }
    }
    this.RemoveAllConfVideoDevices = function () {
        this._confVideoDeviceList.splice(0, this._confVideoDeviceList.length); //delete all conf members
        return true;
    }

}

//ConferenceStateClass methods define
ConferenceStateClass.prototype = {
    GetLocalDeviceList: function () {
        var deviceInfo = ConferenceExcute("GetLocalVideoDevices");
        var obj = JSON.parse(deviceInfo);
        return obj.devicesInfo;
    },
	GetPresenter:function(){
		var presenterInfo = ConferenceExcute("GetPresenter");
		var obj = JSON.parse(presenterInfo);
		if (parseInt(obj.resultCode) === 0)
		{
			return obj.userId;
		}
		else
		{
			return null;
		}
	},
    SetMemberEntered: function (userID, userFlag, userRole) {
        if (this.AddConfMember(userID, userFlag, userRole)) {
            ConferenceUI.UpdateWhenConfMemberEntered(userID, userRole);
        }
    },
    SetMemberLeaved: function (userID, isSelf) {
        if (this.RemoveConfMember(userID)) {
            ConferenceUI.UpdateWhenConfMemberLeaved(userID);
        }
    },
    SetVideoDeviceOpened: function (userID, deviceID) {
        if (this.AddConfVideoDevice(userID, deviceID)) {
            ConferenceUI.UpdateWhenVideoDeviceOpened(userID, deviceID);
        }
    },
    SetVideoDeviceClosed: function (userID, deviceID) {
        if (this.RemoveConfVideoDevice(userID, deviceID)) {
            ConferenceUI.UpdateWhenVideoDeviceClosed(userID, deviceID);
        }
    },
    SetJoiningConf: function (confInfo) {
        this.SetJoinedConfInfo(confInfo);
    },
    SetJoiningConfResultSuccess: function (resultCode) {
        var confID = UTIL.GetFieldValueFromConfInfo(this.GetJoinedConfInfo(), "ConfID");
        var selfUserID = UTIL.GetFieldValueFromConfInfo(this.GetJoinedConfInfo(), "UserID");
        this.SetCurrentJoinedConfID(confID);
        this.SetSelfUserID(selfUserID);
		this.SetDesktopShareControlUser('');
		//when first join meeting, the user can't be sharing desktop
		this.SetIsSharingDesktop(false);
        ConferenceUI.UpdateWhenJoinConfSuccess(resultCode);
    },
    SetJoiningConfResultFailed: function (resultCode) {
        var confID = UTIL.GetFieldValueFromConfInfo(this.GetJoinedConfInfo(), "ConfID");
        var selfUserID = UTIL.GetFieldValueFromConfInfo(this.GetJoinedConfInfo(), "UserID");
        this.SetCurrentJoinedConfID(confID);
        this.SetSelfUserID(selfUserID);
        this.SetDesktopShareControlUser('');
        INFO_LOG_METHOD("ConferenceState", "ConferenceState, warning!!!!!! join conf failed");
        ConferenceUI.UpdateWhenJoinConfFailed(resultCode);
    },
    SetTeminateConfResultSuccess: function () {
        //remove all confmember when meeting ended
        this.RemoveAllConfMembers();
        ConferenceUI.UpdateWhenConfMeetingTeminatedSuccess(this.GetCurrentJoinedConfID());
        this.SetCurrentJoinedConfID('');
        this.SetSelfUserID('');
		this.SetDesktopShareControlUser('');
		//when meeting ends, the user can't be sharing desktop
		this.SetIsSharingDesktop(false);
    },
    SetTeminateConfReulstFailed: function (resultCode) {
        INFO_LOG_METHOD("ConferenceState", "ConferenceState, warning!!!!!! conf teminate failed");
        ConferenceUI.UpdateWhenConfMeetingTeminatedFailed(this.GetCurrentJoinedConfID());
    },
    SetFileArrived: function (fileHandle, fileName, fileSize, fileStatus, senderId) {
        ConferenceUI.UpdateWhenFileArrived(fileHandle, fileName, fileSize);
    },
    SetFileTransSendProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId, resultCode) {
        ConferenceUI.UpdateWhenFileTransSendProgress(fileHandle, fileName, fileSize, fileProgress, senderId, resultCode);
    },
    SetFileTransRecvProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId,resultCode) {
        ConferenceUI.UpdateWhenFileTransRecvProgress(fileHandle, fileName, fileSize, fileProgress, senderId, resultCode);
    },
    SetFileTransSendOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        ConferenceUI.UpdateWhenFileTransSendOverSuccess(fileHandle, fileName, fileSize, senderId);
    },
    SetFileTransSendOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {
        ConferenceUI.UpdateWhenFileTransSendOverFailed(fileHandle, fileName, fileSize, senderId, resultCode);
    },
    SetFileTransRecvOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        ConferenceUI.UpdateWhenFileTransRecvOverSuccess(fileHandle, fileName, fileSize, senderId);
    },
    SetFileTransRecvOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {
        ConferenceUI.UpdateWhenFileTransRecvOverFailed(fileHandle, fileName, fileSize, senderId, resultCode);
    },
	SetOperationPrivilegeState: function(action, privilegeType, userId){
		if (privilegeType === "remotectl"){
			if (action === "delete")
			{
				if (parseInt(userId) !== ConferenceState.GetSelfUserID())
				{
					this.SetDesktopShareControlUser('');
				}
			}
			else if (action === "add"){
				if (parseInt(userId) !== ConferenceState.GetSelfUserID() && this.GetIsSharingDesktop())
				{
					this.SetDesktopShareControlUser(userId);
				}
			}
		}
		ConferenceUI.UpdateWhenSetOperationPrivilegeState(action, privilegeType, userId);
	},
	SetStartShareScreenResult: function(resultCode){
		this.SetDesktopShareControlUser('');
		this.SetIsSharingDesktop(true);
		ConferenceUI.UpdateWhenStartShareScreenResult(resultCode);
	}
}