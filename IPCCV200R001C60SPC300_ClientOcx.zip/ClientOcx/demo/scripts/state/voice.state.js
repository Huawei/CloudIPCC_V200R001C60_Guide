//voice register state define
VOICE_PHONE_REGISTER_STATE = {
    VOICE_PHONE_UNREGISTERED:0,
    VOICE_PHONE_REGISTERED:1
}
//voice talking state define
VOICE_PHONE_TALKING_STATE = {
    VOICE_PHONE_RELEASED:0,  
    VOICE_PHONE_ALERTING:1,
    VOICE_PHONE_TALKING:2

}
//VoiceStateClass Constructor
function VoiceStateClass() {
    this._currentCallid = "";
    this._registeredPhoneNumber = "";
    this._callingPhoneNumber = "";
    this._registerState = VOICE_PHONE_REGISTER_STATE.VOICE_PHONE_UNREGISTERED;
    this._talkingState = VOICE_PHONE_TALKING_STATE.VOICE_PHONE_RELEASED;
    this.SetCurrentCallID = function (callid) {
        this._currentCallid = callid;
    }
    this.GetCurrentCallID = function () {
        return this._currentCallid;
    }

    this.SetVoiceRegisterState = function (state) {
        this._registerState = state;
    }
    this.GetVoiceRegisterState = function () {
        return this._registerState;
    }
    this.SetVoiceTalkingState = function (state) {
        this._talkingState = state;
    }
    this.GetVoiceTalkingState = function () {
        return this._talkingState;
    }
    this.SetRegisteredPhoneNumber = function (phoneNumber) {
        this._registeredPhoneNumber = phoneNumber;
    }
    this.GetRegisteredPhoneNumber = function () {
        return this._registeredPhoneNumber;
    }
    
    this.SetCallingPhoneNumber = function (phoneNumber) {
        this._callingPhoneNumber = phoneNumber;
    }
    this.GetCallingPhoneNumber = function () {
        return this._callingPhoneNumber;
    }
}
//VoiceStateClass methods define
VoiceStateClass.prototype = {
    SetRegistered: function () {
        this.SetVoiceRegisterState(VOICE_PHONE_REGISTER_STATE.VOICE_PHONE_REGISTERED);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetUnregistered: function () {
        this.SetVoiceRegisterState(VOICE_PHONE_REGISTER_STATE.VOICE_PHONE_UNREGISTERED);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetAlerting: function () {
        this.SetVoiceTalkingState(VOICE_PHONE_TALKING_STATE.VOICE_PHONE_ALERTING);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetTalking: function () {
        this.SetVoiceTalkingState(VOICE_PHONE_TALKING_STATE.VOICE_PHONE_TALKING);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetReleased: function() {   
        this.SetVoiceTalkingState(VOICE_PHONE_TALKING_STATE.VOICE_PHONE_RELEASED);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetCallID: function (callid) {
        this.SetCurrentCallID(callid);
        VoicePhoneUI.UpdateVoicePhoneState();
    },
    SetRegistedPhoneNumber: function (phoneNumber) {
        this.SetRegisteredPhoneNumber(phoneNumber);
        VoicePhoneUI.UpdateVoicePhoneState();
    }

}